#pragma once

namespace Dissector {
	namespace IL2CPP {
		class IL2CPPClass {
		public:

		};

		class IL2CPPMethod {
		public:
			IL2CPPMethod* methodPtr;
		};

		class IL2CPPField {
		public:

		};
	}
}