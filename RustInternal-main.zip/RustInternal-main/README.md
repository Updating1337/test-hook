# RustInternal
Small Rust Internal Base i set up within a day or something
